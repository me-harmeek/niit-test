// nice select

if ($('select').length) {

    $(document).ready(function() {
        $('select').niceSelect();

    });

}
